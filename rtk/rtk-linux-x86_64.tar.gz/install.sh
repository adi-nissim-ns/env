#!/usr/bin/env bash
# RTK installer for NextSilicon dev servers
# Installs rtk binary and wires it into Claude Code as a PreToolUse hook.
# Usage: bash install.sh [--uninstall]
set -euo pipefail

BINARY_NAME="rtk"
INSTALL_DIR="${HOME}/.local/bin"
SETTINGS_FILE="${HOME}/.claude/settings.json"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BINARY_SRC="${SCRIPT_DIR}/${BINARY_NAME}"

# ── helpers ──────────────────────────────────────────────────────────────────

info()  { echo "[rtk-install] $*"; }
warn()  { echo "[rtk-install] WARN: $*" >&2; }
die()   { echo "[rtk-install] ERROR: $*" >&2; exit 1; }

# Merge the Claude Code PreToolUse hook into settings.json using Python.
# Handles: file missing, empty file, existing hooks with other matchers.
merge_hook() {
    python3 - "${SETTINGS_FILE}" <<'PYEOF'
import json, sys, os
from pathlib import Path

path = sys.argv[1]
os.makedirs(os.path.dirname(path), exist_ok=True)

try:
    with open(path) as f:
        cfg = json.load(f)
except (FileNotFoundError, json.JSONDecodeError):
    cfg = {}

hook_entry = {"type": "command", "command": str(Path.home() / ".local/bin/rtk") + " hook claude"}
matcher    = {"matcher": "Bash", "hooks": [hook_entry]}

hooks = cfg.setdefault("hooks", {})
pre   = hooks.setdefault("PreToolUse", [])

# check if our hook is already there
for entry in pre:
    if entry.get("matcher") == "Bash":
        for h in entry.get("hooks", []):
            if h.get("command") == "rtk hook claude":
                print("  hook already present — nothing to do")
                sys.exit(0)

pre.append(matcher)

with open(path, "w") as f:
    json.dump(cfg, f, indent=2)
    f.write("\n")

print(f"  hook added to {path}")
PYEOF
}

# Remove only the rtk hook entry from settings.json, leave everything else.
remove_hook() {
    python3 - "${SETTINGS_FILE}" <<'PYEOF'
import json, sys, os

path = sys.argv[1]
if not os.path.exists(path):
    print("  settings.json not found — nothing to do")
    sys.exit(0)

with open(path) as f:
    cfg = json.load(f)

pre = cfg.get("hooks", {}).get("PreToolUse", [])
new_pre = []
removed = False
for entry in pre:
    if entry.get("matcher") == "Bash":
        filtered = [h for h in entry.get("hooks", []) if "rtk hook claude" not in h.get("command", "")]
        if len(filtered) != len(entry.get("hooks", [])):
            removed = True
        if filtered:
            new_pre.append({**entry, "hooks": filtered})
    else:
        new_pre.append(entry)

if not removed:
    print("  rtk hook not found — nothing to do")
    sys.exit(0)

cfg["hooks"]["PreToolUse"] = new_pre

with open(path, "w") as f:
    json.dump(cfg, f, indent=2)
    f.write("\n")

print(f"  hook removed from {path}")
PYEOF
}

# ── uninstall ─────────────────────────────────────────────────────────────────

if [[ "${1:-}" == "--uninstall" ]]; then
    info "Uninstalling rtk..."
    remove_hook
    if [[ -f "${INSTALL_DIR}/${BINARY_NAME}" ]]; then
        rm "${INSTALL_DIR}/${BINARY_NAME}"
        info "Binary removed from ${INSTALL_DIR}/${BINARY_NAME}"
    else
        warn "Binary not found at ${INSTALL_DIR}/${BINARY_NAME}"
    fi
    info "Done."
    exit 0
fi

# ── install ───────────────────────────────────────────────────────────────────

info "Installing rtk v$(${BINARY_SRC} --version 2>/dev/null | awk '{print $2}' || echo '?')..."

# 1. binary
[[ -f "${BINARY_SRC}" ]] || die "Binary not found at ${BINARY_SRC}"
mkdir -p "${INSTALL_DIR}"
cp "${BINARY_SRC}" "${INSTALL_DIR}/${BINARY_NAME}"
chmod +x "${INSTALL_DIR}/${BINARY_NAME}"
info "Binary installed to ${INSTALL_DIR}/${BINARY_NAME}"

# 2. PATH check
if ! echo ":${PATH}:" | grep -q ":${INSTALL_DIR}:"; then
    warn "${INSTALL_DIR} is not in PATH."
    warn "Add this to your shell profile:"
    warn "  export PATH=\"\${HOME}/.local/bin:\${PATH}\""
fi

# 3. verify binary works
"${INSTALL_DIR}/${BINARY_NAME}" --version > /dev/null || die "Binary does not run — wrong architecture or missing libc?"

# 4. Claude Code hook
if [[ ! -d "${HOME}/.claude" ]]; then
    warn "~/.claude directory not found — is Claude Code installed?"
    warn "Hook not installed. Run the following after installing Claude Code:"
    warn "  rtk init -g"
    exit 0
fi

info "Merging Claude Code hook into ${SETTINGS_FILE}..."
merge_hook

info "Done. Restart Claude Code (or start a new session) to activate the hook."
info "Test with: git status   (output should be compressed)"
info "Toggle off per-command: RTK_DISABLED=1 git status"
